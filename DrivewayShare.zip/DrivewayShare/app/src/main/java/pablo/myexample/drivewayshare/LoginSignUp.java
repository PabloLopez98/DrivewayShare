package pablo.myexample.drivewayshare;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class LoginSignUp extends AppCompatActivity {

    private FirebaseAuth mAuth;

    EditText email;
    EditText password;
    Button login;
    TextView signUp;

    //If sign in button is pressed, this method is called passing in email and password
    //if login is successful, the user is sent to the map screen
    public void signInUser(String email, String password){

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(LoginSignUp.this, new OnCompleteListener<AuthResult>() {

            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    Intent intent = new Intent(LoginSignUp.this, barActivity.class);
                    startActivity(intent);
                    finish();

                }else{

                    Toast.makeText(getApplicationContext(), "Login unsuccessful.", Toast.LENGTH_LONG).show();

                }

            }
        });
    }

    //if login button is pressed, it checks for empty fields, and calls signInUser()
    public void Login(View view){

        if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){

            Toast.makeText(getApplicationContext(), "Try Again", Toast.LENGTH_LONG).show();

        }else{

            signInUser(email.getText().toString(), password.getText().toString());

        }

    }

    //if 'create account' text is clicked, app takes them to sign up screen
    public void toCreateAccount(View view){

        Intent intent = new Intent(LoginSignUp.this, signup.class);
        startActivity(intent);
        finish();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sign_up);

        mAuth = FirebaseAuth.getInstance();

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.loginButton);
        signUp = findViewById(R.id.signUp);

    }

    //This method hides the keyboard if certain parts of the screen are touched
    public void hideKeyBoard(View view) {

        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);

    }
}
