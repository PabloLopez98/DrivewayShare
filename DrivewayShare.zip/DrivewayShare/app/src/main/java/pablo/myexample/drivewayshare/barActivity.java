package pablo.myexample.drivewayshare;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Fade;
import android.view.MenuItem;
import android.view.View;

import pablo.myexample.drivewayshare.fragments.ChatFragment;
import pablo.myexample.drivewayshare.fragments.MapFragment;
import pablo.myexample.drivewayshare.fragments.MyPostFragment;
import pablo.myexample.drivewayshare.fragments.MyReservationFragment;

public class barActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    Fragment fragment;

     public static void hideBottomNavigationView(View view) {
        view.clearAnimation();
        view.animate().translationY(view.getHeight());
    }

     public static void showBottomNavigationView(View view) {
        view.clearAnimation();
        view.animate().translationY(0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar);

        bottomNavigationView = findViewById(R.id.botNav);
        bottomNavigationView.setOnNavigationItemSelectedListener(listener);

        getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new MapFragment()).commit();

    }

    private BottomNavigationView.OnNavigationItemSelectedListener listener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            switch (menuItem.getItemId()){

                case R.id.map:
                    fragment = new MapFragment();
                    break;

                case R.id.mypost:
                    fragment = new MyPostFragment();
                    break;

                case R.id.reservations:
                    fragment = new MyReservationFragment();
                    break;

                case R.id.chat:
                    fragment = new ChatFragment();
                    break;

            }

            getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, fragment).commit();
            return true;

        }
        };
}
