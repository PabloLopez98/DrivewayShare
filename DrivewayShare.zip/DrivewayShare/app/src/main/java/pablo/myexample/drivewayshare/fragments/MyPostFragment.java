package pablo.myexample.drivewayshare.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.net.sip.SipSession;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.firebase.FirebaseAppLifecycleListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import pablo.myexample.drivewayshare.Adapter;
import pablo.myexample.drivewayshare.LoginSignUp;
import pablo.myexample.drivewayshare.MyPost;
import pablo.myexample.drivewayshare.R;
import pablo.myexample.drivewayshare.User;
import pablo.myexample.drivewayshare.inputMyPostInfo;
import pablo.myexample.drivewayshare.profile;

public class MyPostFragment extends Fragment implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    RecyclerView recyclerView;
    Adapter adapter;
    public static List<MyPost> MyPostList;
    FirebaseAuth firebaseAuth;
    DrawerLayout drawer;
    Button menuButton;
    Button addPostButton;
    NavigationView navigationView;
    DatabaseReference mRef;
    DatabaseReference mRef2;
    FirebaseDatabase database;
    String userId;

    //for the listener of data
    ValueEventListener valueEventListener;
    ValueEventListener valueEventListener2;

    //to see if entered already
    Boolean entered = false;

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        mRef.removeEventListener(valueEventListener);
        mRef2.removeEventListener(valueEventListener2);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_post, container, false);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        Intent intent;

        switch (menuItem.getItemId()){

            case R.id.logout:
                firebaseAuth.getInstance().signOut();
                intent = new Intent(getActivity(), LoginSignUp.class);
                startActivity(intent);
                getActivity().finish();
                break;

            case R.id.profile:
                intent = new Intent(getActivity(), profile.class);
                startActivity(intent);
                break;

        }

        return true;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        drawer = getView().findViewById(R.id.drawerlayout);
        menuButton = getView().findViewById(R.id.menubutton);
        menuButton.setOnClickListener(this);
        addPostButton = getView().findViewById(R.id.addPostButton);
        addPostButton.setOnClickListener(this);
        navigationView = getView().findViewById(R.id.navView);
        navigationView.setNavigationItemSelectedListener(this);

        MyPostList = new ArrayList<>();
        recyclerView = getView().findViewById(R.id.recycleriView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        database = FirebaseDatabase.getInstance();
        FirebaseUser firebaseUser = firebaseAuth.getInstance().getCurrentUser();
        userId = firebaseUser.getUid();

            mRef = database.getReference().child("Users").child(userId);
            valueEventListener = mRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    User user = dataSnapshot.getValue(User.class);
                    NavigationView navigationView = getView().findViewById(R.id.navView);
                    View headerView = navigationView.getHeaderView(0);
                    TextView name = headerView.findViewById(R.id.nameDisplay);
                    name.setText(user.getUserName());
                    TextView carmodel = headerView.findViewById(R.id.carmodelDisplay);
                    carmodel.setText(user.getCarModel());
                    TextView licenseplate = headerView.findViewById(R.id.licenseplateDisplay);
                    licenseplate.setText(user.getLicensePlate());

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });

        //Make it so that i loop through all child nodes of MyPostInfo Child to display all cards!!!
        mRef2 = database.getReference().child("Users").child(userId).child("MyPostInfo");
        valueEventListener2 = mRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.exists()) {
                    if(entered == false){
                        for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            MyPost myPost = dataSnapshot1.getValue(MyPost.class);
                            MyPostList.add(myPost);
                    }
                    adapter = new Adapter(getContext(), MyPostFragment.MyPostList);
                    recyclerView.setAdapter(adapter);
                    entered = true;
                    }else{
                        //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new MyPostFragment()).commit();
                        MyPostFragment f = new MyPostFragment();
                        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_content, f);
                        transaction.addToBackStack(null);
                        transaction.commit();
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.menubutton:
                drawer.openDrawer(Gravity.START);
                break;
            case R.id.addPostButton:
                Intent toinputMyPostInfo = new Intent(getContext(), inputMyPostInfo.class);
                startActivity(toinputMyPostInfo);
                break;
         }

    }
}