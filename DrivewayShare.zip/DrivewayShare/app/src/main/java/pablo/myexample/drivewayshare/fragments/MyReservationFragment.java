package pablo.myexample.drivewayshare.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import pablo.myexample.drivewayshare.Adapter;
import pablo.myexample.drivewayshare.AdapterTwo;
import pablo.myexample.drivewayshare.LoginSignUp;
import pablo.myexample.drivewayshare.MyPost;
import pablo.myexample.drivewayshare.MyReservation;
import pablo.myexample.drivewayshare.R;
import pablo.myexample.drivewayshare.User;
import pablo.myexample.drivewayshare.inputMyPostInfo;
import pablo.myexample.drivewayshare.profile;

import static pablo.myexample.drivewayshare.R.id.drawerlayout;

public class MyReservationFragment extends Fragment implements NavigationView.OnNavigationItemSelectedListener{

    DrawerLayout drawer;
    RecyclerView recyclerView;
    AdapterTwo theAdapter;
    public static List<MyReservation> MyReservationList;
    FirebaseAuth firebaseAuth;
    Button menuButton;
    NavigationView navigationView;
    DatabaseReference mRef;
    DatabaseReference mRef2;
    FirebaseDatabase database;
    FirebaseUser firebaseUser;
    String userId;
    ValueEventListener valueEventListener;
    ValueEventListener valueEventListener2;

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mRef.removeEventListener(valueEventListener);
        mRef2.removeEventListener(valueEventListener2);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Intent intent;
        switch (menuItem.getItemId()){
            case R.id.logout:
                firebaseAuth.getInstance().signOut();
                intent = new Intent(getActivity(), LoginSignUp.class);
                startActivity(intent);
                getActivity().finish();
                break;
            case R.id.profile:
                intent = new Intent(getActivity(), profile.class);
                startActivity(intent);
                break;
        }
        return true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_my_reservation, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        drawer = getView().findViewById(R.id.drawerlayout);
        menuButton = getView().findViewById(R.id.menuResbutton);
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawer.openDrawer(Gravity.START);
            }
        });
        navigationView = getView().findViewById(R.id.navView);
        navigationView.setNavigationItemSelectedListener(this);

        MyReservationList = new ArrayList<>();
        recyclerView = getView().findViewById(R.id.recycleriView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        database = FirebaseDatabase.getInstance();
        firebaseUser = firebaseAuth.getInstance().getCurrentUser();
        userId = firebaseUser.getUid();

        //displays menu info
        mRef = database.getReference().child("Users").child(userId);
        valueEventListener = mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                User user = dataSnapshot.getValue(User.class);
                NavigationView navigationView = getView().findViewById(R.id.navView);
                View headerView = navigationView.getHeaderView(0);
                TextView name = headerView.findViewById(R.id.nameDisplay);
                name.setText(user.getUserName());
                TextView carmodel = headerView.findViewById(R.id.carmodelDisplay);
                carmodel.setText(user.getCarModel());
                TextView licenseplate = headerView.findViewById(R.id.licenseplateDisplay);
                licenseplate.setText(user.getLicensePlate());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        //Make it so that i loop through all child nodes of MyReservationInfo Child to display all reservation cards!!!
        mRef2 = database.getReference().child("Users").child(userId).child("MyReservationInfo");
        valueEventListener2 = mRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        MyReservation myReservation = dataSnapshot1.getValue(MyReservation.class);
                        MyReservationList.add(myReservation);
                        theAdapter = new AdapterTwo(getContext(), MyReservationFragment.MyReservationList);
                        recyclerView.setAdapter(theAdapter);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }
}
