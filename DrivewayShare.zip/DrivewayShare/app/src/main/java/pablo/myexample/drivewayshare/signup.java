package pablo.myexample.drivewayshare;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signup extends AppCompatActivity {

    private FirebaseAuth mAuth;

    Button backarrow;

    EditText username;
    EditText email;
    EditText password;
    EditText confirmpassword;

    public void signUpUser(final String email, String password, final String userName){
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(signup.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    //Adding new users to database, with empty license plates and car model numbers
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    FirebaseUser firebaseUser = mAuth.getInstance().getCurrentUser();
                    String userId = firebaseUser.getUid();
                    User user = new User(userName, "null", "null");
                    DatabaseReference mRef = database.getReference().child("Users").child(userId);
                    mRef.setValue(user);

                    Intent intent = new Intent(signup.this, barActivity.class);
                    startActivity(intent);
                    finish();

                }else{

                    String s = "Sign up Failed: " + task.getException();
                    Toast.makeText(signup.this, s, Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    //If sign up button is touched, empty fields and password length is checked
    //if all is fine, signUpUser() is called
    public void SignUp(View view){

        if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){

            Toast.makeText(this, "Missing field.", Toast.LENGTH_LONG).show();

        }else if (!password.getText().toString().equals(confirmpassword.getText().toString())){

            Toast.makeText(this, "Check password confirmation.", Toast.LENGTH_LONG).show();

        }
        else if (password.getText().toString().length() < 6){

            Toast.makeText(this, "Password cannot be under 6 characters.", Toast.LENGTH_LONG).show();

        }
        else{

            signUpUser(email.getText().toString(), password.getText().toString(), username.getText().toString());

        }

    }

    //if back arrow is touched, then user returns to login screen
    public void goBack(View view){

        Intent intent = new Intent(signup.this, LoginSignUp.class);
        startActivity(intent);
        finish();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mAuth = FirebaseAuth.getInstance();

        username = findViewById(R.id.usernameinput);
        email = findViewById(R.id.emailinput);
        password = findViewById(R.id.passwordinput);
        confirmpassword = findViewById(R.id.confirmpasswordinput);

        backarrow = findViewById(R.id.backarrow);

    }

    //This method hides the keyboard if certain parts of the screen are touched
    public void hideKeyBoardAgain(View view){

        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);

    }
}
